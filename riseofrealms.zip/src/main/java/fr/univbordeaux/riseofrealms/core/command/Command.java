package fr.univbordeaux.riseofrealms.core.command;

public interface Command {
    void execute();
}
