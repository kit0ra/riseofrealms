package fr.univbordeaux.riseofrealms.core.strategy;

import fr.univbordeaux.riseofrealms.people.Person;

public interface Behavior {
    void execute(Person person);
}
