package fr.univbordeaux.riseofrealms.core.observer;

public interface Observer {
    void update(String resource, int quantity);
}
