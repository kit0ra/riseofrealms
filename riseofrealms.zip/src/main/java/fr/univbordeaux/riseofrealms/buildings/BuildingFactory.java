package fr.univbordeaux.riseofrealms.buildings;

public interface BuildingFactory {
    Building createBuilding(String type);
}